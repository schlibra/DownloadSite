<?php

class MySQL
{
    private $conn;

    public function __construct()
    {
        $mysql_config = parse_ini_file("mysql.ini");
        $conn = mysqli_connect(
            $mysql_config["hostname"] ?? "hostname",
            $mysql_config["username"] ?? "root",
            $mysql_config["password"] ?? "123456",
            $mysql_config["database"] ?? "root",
            $mysql_config["port"] ?? 3306
        );
        if ($conn) {
            $this->conn = $conn;
        }else{
            return json_encode(["code"=>500,"msg"=>"数据库连接失败：" . mysqli_connect_error()]);
        }

    }
    public function query($query)
    {
        $result = mysqli_query($this->conn, $query);
        if ($result){
            return $result;
        }else{
            die(json_encode(["code"=>500, "msg"=>"数据库执行失败：" . mysqli_error($this->conn)]));
        }
    }
}